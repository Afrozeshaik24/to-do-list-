import { useEffect, useState } from "react";
import Card from "./components/Card";
import {GetAllTodos ,  handleSubmitTodo} from "./helpers/todoHelpers" 


function App () {
  const [newTodo , setNewTodo] = useState("");
  const [description , setDescription] = useState("");
  const [todos , setTodos] = useState([]);
  const [randomState , setRandomState] = useState("");
  function handleChangeInput(e) {
    console.log(e.target.value);
    setNewTodo(e.target.value)
  } 
  
  function handleDescription(e) {
    setDescription(e.target.value)
  }
  
  
  useEffect(()=>{
    GetAllTodos(setTodos);
  },[newTodo , randomState])


  return (
    <div style={
      {
      }
    }>
      {/* this is my input wala part */}
          <div style={{
            display : "flex" ,
            padding : "20px" ,
            gap : "10px" ,
            flexDirection : "column",
            
          }}>
            <p>{randomState}</p>
            <input style={{
              padding : '10px',
              width : "150px"
            }} placeholder="Todo" onChange={handleChangeInput} />
            <input style={{
              padding : '10px', 
              width : "350px"
            }} type="text" placeholder="Description" onChange={handleDescription} />
            <button style={{
              width : "150px" 
            }} onClick={() => handleSubmitTodo(newTodo , description , setNewTodo)}>Add Todo</button>
          </div>



  {/* this will be the   todo display part */}

      <div 
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "1rem",
        maxWidth: "1000px"
        
      }}>
        {
          todos.map((x)=>(
            <>
              <Card todo={x} setRandomState={setRandomState}  />
            </>
          ))
         

        }
        </div>
          
    </div>
  )
}





export default App;
// we will create a todo list app 

/**


- so basically we need to impliment a completed button
- and we also need to add a delete todo button 


* 
 * 
 */