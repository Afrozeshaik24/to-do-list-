import React from 'react'
import { handleCompleteTodo, handleDeleteTodo } from '../helpers/todoHelpers'

const Card = ({todo , setRandomState}) => {
  return (
    <div style={{
        borderRadius : "20px" ,
        borderStyle : "solid" ,
        borderColor : "white",
        width : "170px",
        padding : "20px",
      }}>
        <button style={{
          backgroundColor : "white" ,
          padding : "10px"
        }} onClick={()=>handleDeleteTodo(todo.id , todo.name , setRandomState )}>❌</button>
        <h3>{todo.name}</h3>
        {/* below will be the description */}
        <p>{todo.description}</p>
        {
          todo.isCompleted ? <p >Completed </p> : <button onClick={() => handleCompleteTodo(todo.id , todo.name , setRandomState)}>Complete ✔️</button>
        } 
      </div>
  )
}

export default Card
